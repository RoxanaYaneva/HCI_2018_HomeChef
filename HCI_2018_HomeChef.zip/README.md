# HCI_2018_HomeChef
Course Project, HCI, 2018, FMI

Link to description:
https://github.com/RoxanaYaneva/HCI_2018_HomeChef/blob/master/HCI_HomeChef_61934_61871_61927.pdf
