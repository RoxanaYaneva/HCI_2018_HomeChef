$("#addImageBtn").click(function(e) {
	$("#addImage").click();
});

$("#addVideoBtn").click(function(e) {
	$("#addVideo").click();
});
